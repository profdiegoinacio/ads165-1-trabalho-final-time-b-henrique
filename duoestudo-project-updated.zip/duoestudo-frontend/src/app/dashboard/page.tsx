
'use client'
import useSWR from 'swr';
import axios from 'axios';
import Link from 'next/link';

interface Ticket{
  id:number;
  title:string;
  subject:string;
  level:string;
  status:string;
}

const fetcher = (url:string) => axios.get(url,
  {headers:{Authorization:`Bearer ${localStorage.getItem('token')}`}}
).then(res=>res.data);

export default function Dashboard(){
  const {data:tickets, error, isLoading} = useSWR<Ticket[]>('http://localhost:8080/api/v1/tickets', fetcher);

  if(isLoading) return <p className="p-4">Carregando...</p>;
  if(error) return <p className="p-4">Erro ao carregar.</p>;

  return (
    <main className="p-4 max-w-md mx-auto space-y-2">
      <Link href="/tickets/new" className="block bg-primary text-white text-center py-2 rounded-xl mb-4">Criar Chamado</Link>
      {tickets?.map(t => (
        <Link key={t.id} href={`/tickets/${t.id}`} className="block rounded-xl p-4 bg-gray-100">
          <h3 className="font-medium">{t.title}</h3>
          <p className="text-sm text-gray-500">{t.level} · {t.subject}</p>
          <span className="text-xs">{t.status.toLowerCase()}</span>
        </Link>
      ))}
    </main>
  );
}
