
'use client'
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

export default function NewTicketPage(){
  const [title,setTitle] = useState('');
  const [subject,setSubject] = useState('');
  const [level,setLevel] = useState('');
  const router = useRouter();

  const create = async (e:any)=>{
    e.preventDefault();
    await axios.post('http://localhost:8080/api/v1/tickets',
        {title, subject, level},
        {headers:{Authorization:`Bearer ${localStorage.getItem('token')}`}}
    );
    router.push('/dashboard');
  }

  return(
    <main className="flex items-center justify-center h-[calc(100vh-56px)]">
      <form onSubmit={create} className="bg-white p-6 rounded-2xl shadow w-80 space-y-3">
        <h2 className="text-lg font-semibold text-center">Novo Chamado</h2>
        <input placeholder="Título" className="w-full border p-2 rounded" value={title} onChange={e=>setTitle(e.target.value)}/>
        <input placeholder="Disciplina" className="w-full border p-2 rounded" value={subject} onChange={e=>setSubject(e.target.value)}/>
        <input placeholder="Nível" className="w-full border p-2 rounded" value={level} onChange={e=>setLevel(e.target.value)}/>
        <button className="w-full bg-primary text-white py-2 rounded-lg">Criar</button>
      </form>
    </main>
  )
}
