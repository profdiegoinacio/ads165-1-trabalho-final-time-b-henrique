
'use client'
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import axios from 'axios';
import { useState } from 'react';

interface Message{
  id:number;
  senderId:number;
  content:string;
  createdAt:string;
}
interface Ticket{
  id:number;
  title:string;
  messages:Message[];
}

const fetcher = (url:string) => axios.get(url,
  {headers:{Authorization:`Bearer ${localStorage.getItem('token')}`}}
).then(res=>res.data);

export default function TicketChat(){
  const { id } = useParams();
  const {data:ticket, mutate} = useSWR<Ticket>(`http://localhost:8080/api/v1/tickets/${id}`, fetcher);
  const [msg,setMsg] = useState('');

  const send = async (e:any)=>{
    e.preventDefault();
    if(!msg.trim()) return;
    await axios.post(`http://localhost:8080/api/v1/tickets/${id}/messages`,
      {content:msg},
      {headers:{Authorization:`Bearer ${localStorage.getItem('token')}`}}
    );
    setMsg('');
    mutate();
  }

  if(!ticket) return <p className="p-4">Carregando...</p>;

  return(
    <main className="flex flex-col h-[calc(100vh-56px)]">
      <header className="p-4 border-b">{ticket.title}</header>
      <ul className="flex-1 overflow-y-auto p-4 space-y-2">
        {ticket.messages.map(m=>(
          <li key={m.id} className="bg-gray-100 max-w-xs p-2 rounded-lg">{m.content}</li>
        ))}
      </ul>
      <form onSubmit={send} className="p-4 flex gap-2">
        <input className="flex-1 border p-2 rounded" value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Mensagem"/>
        <button className="bg-primary text-white px-4 rounded-lg">Enviar</button>
      </form>
    </main>
  )
}
