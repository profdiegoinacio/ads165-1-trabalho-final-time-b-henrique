
'use client'
import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import axios from 'axios';

export default function RatingPage(){
  const {id} = useParams();
  const [stars,setStars] = useState(0);
  const [comment,setComment] = useState('');
  const router = useRouter();

  const send = async (e:any)=>{
    e.preventDefault();
    // endpoint futuro
    alert('Avaliação enviada! Obrigado.');
    router.push('/dashboard');
  }

  return(
    <main className="flex items-center justify-center h-[calc(100vh-56px)]">
      <form onSubmit={send} className="bg-white p-6 rounded-2xl shadow w-80 space-y-4">
        <h2 className="text-center text-xl font-semibold">Avaliação</h2>
        <div className="flex justify-center space-x-1">
          {[1,2,3,4,5].map(n=>(
             <button type="button" key={n} onClick={()=>setStars(n)}>
               <span className={n<=stars ? 'text-yellow-400 text-3xl' : 'text-gray-300 text-3xl'}>★</span>
             </button>
          ))}
        </div>
        <textarea placeholder="Comentário opcional" className="w-full border rounded p-2" rows={3} value={comment} onChange={e=>setComment(e.target.value)} />
        <button className="w-full bg-primary text-white py-2 rounded-lg">Enviar</button>
      </form>
    </main>
  )
}
