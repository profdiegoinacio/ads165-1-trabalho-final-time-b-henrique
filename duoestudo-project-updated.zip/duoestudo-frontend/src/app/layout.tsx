
import './globals.css';
import Link from 'next/link';
import type { ReactNode } from 'react';

export const metadata = {
  title: 'DuoEstudo',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-gray-50 text-gray-900">
        <nav className="px-4 py-2 bg-primary text-white">
          <Link href="/" className="font-semibold">DuoEstudo</Link>
        </nav>
        {children}
      </body>
    </html>
  );
}
