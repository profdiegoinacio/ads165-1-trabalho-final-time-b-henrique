
'use client'
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

export default function LoginPage(){
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async (e:any) => {
    e.preventDefault();
    try{
      const {data} = await axios.post('http://localhost:8080/api/v1/auth/login',{email,password});
      localStorage.setItem('token', data.token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
      router.push('/dashboard');
    }catch(err:any){
      alert('Erro ao logar');
    }
  }

  return(
    <main className="flex items-center justify-center h-[calc(100vh-56px)]">
      <form onSubmit={handleLogin} className="bg-white p-6 rounded-2xl shadow w-80 space-y-4">
        <h1 className="text-xl font-semibold text-center">DuoEstudo</h1>
        <input placeholder="Email" className="w-full border p-2 rounded" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Senha" type="password" className="w-full border p-2 rounded" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full bg-primary text-white py-2 rounded-lg">Entrar</button>
      </form>
    </main>
  )
}
