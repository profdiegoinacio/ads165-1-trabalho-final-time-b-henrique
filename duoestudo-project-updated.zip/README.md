
# DuoEstudo – Projeto Full‑Stack (Spring Boot + Next.js)

Este repositório agrupa **backend** (`duoestudo-api`) e **frontend** (`duoestudo-frontend`) de um mini‑sistema de chamados/ chat para dúvidas estudantis.  
A stack foi montada conforme requisitos de aula:

* **Spring Boot 3.3 + JPA + H2**  
* **JWT** para autenticação  
* **Next.js 14 (App Router) + Tailwind CSS**  

> Tudo já está pronto para **rodar localmente** ou ser entregue a avaliação.

---

## 1. Pré‑requisitos

| Ferramenta | Versão mínima |
|------------|---------------|
| Java | 21 |
| Maven | 3.9 |
| Node | 20 |
| npm | 10 |

---

## 2. Como rodar

### 2.1 Backend

```bash
cd duoestudo-api
./mvnw spring-boot:run
```

* Porta padrão: **8080**  
* H2 Console: <http://localhost:8080/h2> (JDBC URL `jdbc:h2:mem:duodb`)  
* Usuários seed:  

| Email | Senha | Perfil |
|-------|-------|--------|
| `aluno@exemplo.com` | `123` | STUDENT |
| `ajudante@exemplo.com` | `123` | HELPER |

### 2.2 Frontend

Abra outro terminal:

```bash
cd duoestudo-frontend
npm install               # 1ª vez
npm run dev               # porta 3000
```

A aplicação Web em <http://localhost:3000>:

1. **Login** com um dos usuários acima  
2. Criar chamado, responder, encerrar, avaliar.

---

## 3. Estrutura de pastas

```
duoestudo-project/
 ├─ duoestudo-api/       # Spring Boot
 └─ duoestudo-frontend/  # Next.js + Tailwind
```

---

## 4. Próximos passos

* **Persistência real** – substituir H2 por PostgreSQL em `application.yml`.
* **WebSocket** – use `spring-boot-starter-websocket` + `socket.io-client` no front para chat em tempo‑real.
* **Deploy** – containerizar com Docker (ex.: `Dockerfile` + `docker‑compose.yml`).

---

### Bom estudo & boa entrega!
