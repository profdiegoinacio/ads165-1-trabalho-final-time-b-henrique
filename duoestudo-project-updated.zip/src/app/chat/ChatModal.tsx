// src/app/chat/ChatModal.tsx
'use client'
import useSWR from 'swr';
import axios from 'axios';
import { useState } from 'react';

interface Message {
  id: number;
  senderId: number;
  content: string;
  createdAt: string;
}

interface ChatModalProps {
  ticketId: number;
  onClose: () => void;
}

const fetcher = (url: string) => axios.get(url, {
  headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
}).then(res => res.data);

export default function ChatModal({ ticketId, onClose }: ChatModalProps) {
  const { data: ticket, error, isLoading, mutate } = useSWR<any>(`http://localhost:8080/api/v1/tickets/${ticketId}`, fetcher);
  const [msg, setMsg] = useState('');

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msg.trim()) return;
    await axios.post(
      `http://localhost:8080/api/v1/tickets/${ticketId}/messages`,
      { content: msg },
      { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
    );
    setMsg('');
    mutate();
  };

  if (isLoading || error) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-xl w-full max-w-lg h-5/6 flex flex-col">
        <header className="p-4 border-b flex justify-between items-center">
          <h2>{ticket.title}</h2>
          <button onClick={onClose} className="text-gray-500">Fechar</button>
        </header>
        <ul className="flex-1 overflow-y-auto p-4 space-y-2">
          {ticket.messages.map((m: Message) => (
            <li key={m.id} className={`p-2 rounded-lg max-w-xs ${m.senderId === ticket.userId ? 'bg-blue-100 self-start' : 'bg-green-100 self-end'}`}>
              {m.content}
            </li>
          ))}
        </ul>
        <form onSubmit={send} className="p-4 flex gap-2">
          <input value={msg} onChange={e => setMsg(e.target.value)} className="flex-1 border p-2 rounded" placeholder="Mensagem" />
          <button type="submit" className="bg-primary text-white px-4 rounded-lg">Enviar</button>
        </form>
      </div>
    </div>
  );
}
