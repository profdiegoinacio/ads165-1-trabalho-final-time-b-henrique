
package com.duoestudo.dto;

public record AuthRequest(String email, String password) {}
