
package com.duoestudo.dto;

public record AuthResponse(String token) {}
