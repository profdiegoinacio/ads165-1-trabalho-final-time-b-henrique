
package com.duoestudo.dto;

import java.time.LocalDateTime;

public record MessageDTO(
        Long id,
        Long senderId,
        String content,
        LocalDateTime createdAt
) {}
