
package com.duoestudo.dto;

import com.duoestudo.domain.Ticket;
import com.duoestudo.domain.enums.TicketStatus;

import java.util.List;

public record TicketDTO(
        Long id,
        String title,
        String subject,
        String level,
        TicketStatus status,
        Long studentId,
        Long helperId,
        List<MessageDTO> messages
) {
    public static TicketDTO of(Ticket t){
        return new TicketDTO(
            t.getId(),
            t.getTitle(),
            t.getSubject(),
            t.getLevel(),
            t.getStatus(),
            t.getStudent() != null ? t.getStudent().getId() : null,
            t.getHelper() != null ? t.getHelper().getId() : null,
            t.getMessages().stream()
              .map(m -> new MessageDTO(m.getId(),
                                        m.getSender().getId(),
                                        m.getContent(),
                                        m.getCreatedAt()))
              .toList()
        );
    }
}
