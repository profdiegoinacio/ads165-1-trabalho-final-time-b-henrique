
package com.duoestudo.dto;

import jakarta.validation.constraints.NotBlank;

public record CreateTicketRequest(
        @NotBlank String title,
        @NotBlank String subject,
        @NotBlank String level
) {}
