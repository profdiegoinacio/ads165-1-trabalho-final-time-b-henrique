
package com.duoestudo.config;

import com.duoestudo.domain.enums.Role;
import com.duoestudo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final UserService userService;
    @Override
    public void run(String... args) throws Exception {
        userService.register("aluno@exemplo.com","123","Aluno Teste", Role.STUDENT);
        userService.register("ajudante@exemplo.com","123","Ajudante", Role.HELPER);
    }
}
