
package com.duoestudo.service;

import com.duoestudo.domain.*;
import com.duoestudo.domain.enums.TicketStatus;
import com.duoestudo.dto.CreateTicketRequest;
import com.duoestudo.dto.MessageDTO;
import com.duoestudo.repository.MessageRepository;
import com.duoestudo.repository.TicketRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TicketService {

    private final TicketRepository ticketRepo;
    private final MessageRepository messageRepo;

    public Ticket open(CreateTicketRequest req, User student){
        Ticket t = Ticket.builder()
                .title(req.title())
                .subject(req.subject())
                .level(req.level())
                .status(TicketStatus.OPEN)
                .student(student)
                .build();
        return ticketRepo.save(t);
    }

    public List<Ticket> list(){ return ticketRepo.findAll(); }

    public Message addMessage(Long ticketId, MessageDTO dto, User sender){
        Ticket t = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        Message m = Message.builder()
                .ticket(t)
                .sender(sender)
                .content(dto.content())
                .createdAt(LocalDateTime.now())
                .build();
        messageRepo.save(m);
        t.getMessages().add(m);
        if(t.getStatus()== TicketStatus.OPEN){
            t.setStatus(TicketStatus.IN_PROGRESS);
            t.setHelper(sender); // primeira msg do helper marca quem ajuda
        }
        ticketRepo.save(t);
        return m;
    }

    public Ticket close(Long ticketId){
        Ticket t = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        t.setStatus(TicketStatus.RESOLVED);
        return ticketRepo.save(t);
    }
}
