
package com.duoestudo.service;

import com.duoestudo.domain.User;
import com.duoestudo.dto.AuthRequest;
import com.duoestudo.dto.AuthResponse;
import com.duoestudo.repository.UserRepository;
import com.duoestudo.security.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authManager;
    private final JwtUtils jwtUtils;
    private final UserRepository userRepo;

    public AuthResponse login(AuthRequest req){
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        User user = (User) auth.getPrincipal();
        String token = jwtUtils.generateToken(user);
        return new AuthResponse(token);
    }
}
