
package com.duoestudo.service;

import com.duoestudo.domain.User;
import com.duoestudo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(String email, String password, String name, com.duoestudo.domain.enums.Role role){
        if(userRepository.findByEmail(email).isPresent()){
            throw new IllegalArgumentException("Email já cadastrado");
        }
        User user = User.builder()
                        .email(email)
                        .name(name)
                        .role(role)
                        .password(passwordEncoder.encode(password))
                        .build();
        return userRepository.save(user);
    }
}
