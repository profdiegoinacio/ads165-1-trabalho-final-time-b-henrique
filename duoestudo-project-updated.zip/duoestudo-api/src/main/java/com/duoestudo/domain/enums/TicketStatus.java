
package com.duoestudo.domain.enums;

public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED
}
