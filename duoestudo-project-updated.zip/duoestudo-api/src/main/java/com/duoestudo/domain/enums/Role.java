
package com.duoestudo.domain.enums;

public enum Role {
    STUDENT,
    HELPER
}
