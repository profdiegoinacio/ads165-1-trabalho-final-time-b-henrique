
package com.duoestudo.controller;

import com.duoestudo.domain.enums.Role;
import com.duoestudo.dto.AuthRequest;
import com.duoestudo.dto.AuthResponse;
import com.duoestudo.service.AuthService;
import com.duoestudo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final UserService userService;

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request){
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/register")
    public ResponseEntity<Void> register(@RequestBody AuthRequest request){
        userService.register(request.email(), request.password(), "User", Role.STUDENT);
        return ResponseEntity.ok().build();
    }
}
