
package com.duoestudo.controller;

import com.duoestudo.domain.Message;
import com.duoestudo.domain.User;
import com.duoestudo.dto.CreateTicketRequest;
import com.duoestudo.dto.MessageDTO;
import com.duoestudo.dto.TicketDTO;
import com.duoestudo.service.TicketService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/tickets")
@RequiredArgsConstructor
public class TicketController {

    private final TicketService ticketService;

    @GetMapping
    public List<TicketDTO> list(){
        return ticketService.list().stream().map(TicketDTO::of).toList();
    }

    @PostMapping
    public ResponseEntity<TicketDTO> open(@RequestBody CreateTicketRequest body,
                                          @AuthenticationPrincipal User student){
        return ResponseEntity.ok(TicketDTO.of(ticketService.open(body, student)));
    }

    @PostMapping("/{id}/messages")
    public ResponseEntity<MessageDTO> reply(@PathVariable Long id,
                                            @RequestBody MessageDTO body,
                                            @AuthenticationPrincipal User sender){
        Message msg = ticketService.addMessage(id, body, sender);
        MessageDTO dto = new MessageDTO(msg.getId(), sender.getId(), msg.getContent(), msg.getCreatedAt());
        return ResponseEntity.ok(dto);
    }

    @PatchMapping("/{id}/close")
    public ResponseEntity<TicketDTO> close(@PathVariable Long id){
        return ResponseEntity.ok(TicketDTO.of(ticketService.close(id)));
    }
}
