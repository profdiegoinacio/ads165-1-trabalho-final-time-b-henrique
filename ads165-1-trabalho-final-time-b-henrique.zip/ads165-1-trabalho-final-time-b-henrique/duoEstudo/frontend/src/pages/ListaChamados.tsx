export default function ListaChamados() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Lista de Chamados</h1>
      <button className="mb-4 bg-green-500 text-white px-4 py-2 rounded">Criar Chamado</button>
      {/* Aqui vai a listagem dos chamados */}
    </div>
  );
}
