import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import ListaChamados from './pages/ListaChamados';
import ChatChamado from './pages/ChatChamado';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/chamados" element={<ListaChamados />} />
        <Route path="/chamados/:id" element={<ChatChamado />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
