package com.duoestudo.controller;

import com.duoestudo.domain.Chamado;
import com.duoestudo.service.ChamadoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chamados")
public class ChamadoController {
    private final ChamadoService chamadoService;

    public ChamadoController(ChamadoService chamadoService) {
        this.chamadoService = chamadoService;
    }

    @PostMapping
    public ResponseEntity<Chamado> criarChamado(@RequestBody Chamado chamado) {
        Chamado novoChamado = chamadoService.criarChamado(chamado);
        return ResponseEntity.ok(novoChamado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Chamado> buscarPorId(@PathVariable Long id) {
        Chamado chamado = chamadoService.buscarPorId(id);
        return ResponseEntity.ok(chamado);
    }

    @GetMapping
    public ResponseEntity<List<Chamado>> listarTodos() {
        List<Chamado> chamados = chamadoService.listarTodos();
        return ResponseEntity.ok(chamados);
    }

    @GetMapping("/aluno/{alunoId}")
    public ResponseEntity<List<Chamado>> listarPorAluno(@PathVariable Long alunoId) {
        List<Chamado> chamados = chamadoService.listarPorAluno(alunoId);
        return ResponseEntity.ok(chamados);
    }

    @GetMapping("/abertos")
    public ResponseEntity<List<Chamado>> listarAbertos() {
        List<Chamado> chamados = chamadoService.listarAbertos();
        return ResponseEntity.ok(chamados);
    }

    @PutMapping("/{id}/atribuir/{professorId}")
    public ResponseEntity<Chamado> atribuirProfessor(
            @PathVariable Long id,
            @PathVariable Long professorId) {
        Chamado chamado = chamadoService.atribuirProfessor(id, professorId);
        return ResponseEntity.ok(chamado);
    }

    @PutMapping("/{id}/fechar")
    public ResponseEntity<Chamado> fecharChamado(@PathVariable Long id) {
        Chamado chamado = chamadoService.fecharChamado(id);
        return ResponseEntity.ok(chamado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarChamado(@PathVariable Long id) {
        chamadoService.deletarChamado(id);
        return ResponseEntity.noContent().build();
    }
}