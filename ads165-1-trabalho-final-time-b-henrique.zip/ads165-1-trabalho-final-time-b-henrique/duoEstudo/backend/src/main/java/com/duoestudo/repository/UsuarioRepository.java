package com.duoestudo.repository;

import com.duoestudo.domain.Usuario;
import com.duoestudo.domain.enums.TipoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    List<Usuario> findByTipo(TipoUsuario tipo);
}