package com.duoestudo.dto;

import com.duoestudo.domain.enums.TipoUsuario;
import lombok.Data;

@Data
public class UsuarioDTO {
    private Long id;
    private String nome;
    private String email;
    private TipoUsuario tipo;
}