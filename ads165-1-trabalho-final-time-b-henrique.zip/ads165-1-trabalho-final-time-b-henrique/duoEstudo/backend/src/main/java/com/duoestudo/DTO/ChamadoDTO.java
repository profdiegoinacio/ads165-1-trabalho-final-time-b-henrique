package com.duoestudo.dto;

import com.duoestudo.domain.enums.StatusChamado;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ChamadoDTO {
    private Long id;
    private String titulo;
    private String descricao;
    private String materia;
    private StatusChamado status;
    private LocalDateTime dataAbertura;
    private LocalDateTime dataFechamento;
    private Long alunoId;
    private Long professorId;
}