package com.duoestudo.domain.enums;

public enum StatusChamado {
    ABERTO,
    EM_ANDAMENTO,
    RESOLVIDO,
    FECHADO
}