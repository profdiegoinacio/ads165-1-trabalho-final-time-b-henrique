package com.duoestudo.service;

import com.duoestudo.domain.Chamado;
import com.duoestudo.domain.Mensagem;
import com.duoestudo.domain.Usuario;
import com.duoestudo.exception.ResourceNotFoundException;
import com.duoestudo.repository.ChamadoRepository;
import com.duoestudo.repository.MensagemRepository;
import com.duoestudo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MensagemService {
    private final MensagemRepository mensagemRepository;
    private final ChamadoRepository chamadoRepository;
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public MensagemService(MensagemRepository mensagemRepository,
                           ChamadoRepository chamadoRepository,
                           UsuarioRepository usuarioRepository) {
        this.mensagemRepository = mensagemRepository;
        this.chamadoRepository = chamadoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public Mensagem enviarMensagem(Mensagem mensagem, Long chamadoId, Long usuarioId) {
        Chamado chamado = chamadoRepository.findById(chamadoId)
                .orElseThrow(() -> new ResourceNotFoundException("Chamado não encontrado"));
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado"));

        mensagem.setChamado(chamado);
        mensagem.setAutor(usuario);
        mensagem.setDataEnvio(LocalDateTime.now());
        return mensagemRepository.save(mensagem);
    }

    public List<Mensagem> listarPorChamado(Long chamadoId) {
        Chamado chamado = chamadoRepository.findById(chamadoId)
                .orElseThrow(() -> new ResourceNotFoundException("Chamado não encontrado"));
        return mensagemRepository.findByChamado(chamado);
    }

    public Mensagem buscarPorId(Long id) {
        return mensagemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mensagem não encontrada"));
    }

    public void deletarMensagem(Long id) {
        Mensagem mensagem = buscarPorId(id);
        mensagemRepository.delete(mensagem);
    }
}