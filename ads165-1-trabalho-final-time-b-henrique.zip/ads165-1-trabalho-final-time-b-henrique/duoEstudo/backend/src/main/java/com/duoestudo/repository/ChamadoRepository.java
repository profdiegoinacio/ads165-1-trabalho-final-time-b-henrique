package com.duoestudo.repository;

import com.duoestudo.domain.Chamado;
import com.duoestudo.domain.Usuario;
import com.duoestudo.domain.enums.StatusChamado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChamadoRepository extends JpaRepository<Chamado, Long> {
    List<Chamado> findByAluno(Usuario aluno);
    List<Chamado> findByStatus(StatusChamado status);
}