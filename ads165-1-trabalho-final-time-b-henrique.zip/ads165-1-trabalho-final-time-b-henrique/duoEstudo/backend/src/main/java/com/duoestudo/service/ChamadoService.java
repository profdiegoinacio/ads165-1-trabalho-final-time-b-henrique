package com.duoestudo.service;

import com.duoestudo.domain.Chamado;
import com.duoestudo.domain.Usuario;
import com.duoestudo.domain.enums.StatusChamado;
import com.duoestudo.exception.ResourceNotFoundException;
import com.duoestudo.repository.ChamadoRepository;
import com.duoestudo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ChamadoService {
    private final ChamadoRepository chamadoRepository;
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public ChamadoService(ChamadoRepository chamadoRepository, UsuarioRepository usuarioRepository) {
        this.chamadoRepository = chamadoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public Chamado criarChamado(Chamado chamado, Long alunoId) {
        Usuario aluno = usuarioRepository.findById(alunoId)
                .orElseThrow(() -> new ResourceNotFoundException("Aluno não encontrado"));

        chamado.setAluno(aluno);
        chamado.setStatus(StatusChamado.ABERTO);
        chamado.setDataAbertura(LocalDateTime.now());
        return chamadoRepository.save(chamado);
    }

    public Chamado buscarPorId(Long id) {
        return chamadoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Chamado não encontrado"));
    }

    public List<Chamado> listarTodos() {
        return chamadoRepository.findAll();
    }

    public List<Chamado> listarPorAluno(Long alunoId) {
        Usuario aluno = usuarioRepository.findById(alunoId)
                .orElseThrow(() -> new ResourceNotFoundException("Aluno não encontrado"));
        return chamadoRepository.findByAluno(aluno);
    }

    public List<Chamado> listarAbertos() {
        return chamadoRepository.findByStatus(StatusChamado.ABERTO);
    }

    public Chamado atribuirProfessor(Long chamadoId, Long professorId) {
        Chamado chamado = buscarPorId(chamadoId);
        Usuario professor = usuarioRepository.findById(professorId)
                .orElseThrow(() -> new ResourceNotFoundException("Professor não encontrado"));

        chamado.setProfessor(professor);
        chamado.setStatus(StatusChamado.EM_ANDAMENTO);
        return chamadoRepository.save(chamado);
    }

    public Chamado fecharChamado(Long id) {
        Chamado chamado = buscarPorId(id);
        chamado.setStatus(StatusChamado.FECHADO);
        chamado.setDataFechamento(LocalDateTime.now());
        return chamadoRepository.save(chamado);
    }

    public void deletarChamado(Long id) {
        Chamado chamado = buscarPorId(id);
        chamadoRepository.delete(chamado);
    }
}