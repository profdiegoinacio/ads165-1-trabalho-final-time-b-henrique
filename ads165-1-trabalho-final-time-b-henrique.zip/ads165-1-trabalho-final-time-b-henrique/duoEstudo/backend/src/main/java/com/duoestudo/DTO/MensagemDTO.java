package com.duoestudo.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MensagemDTO {
    private Long id;
    private String conteudo;
    private LocalDateTime dataEnvio;
    private Long autorId;
    private Long chamadoId;
}