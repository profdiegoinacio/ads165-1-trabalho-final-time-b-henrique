package com.duoestudo.domain.enums;

public enum TipoUsuario {
    ALUNO,
    PROFESSOR
}